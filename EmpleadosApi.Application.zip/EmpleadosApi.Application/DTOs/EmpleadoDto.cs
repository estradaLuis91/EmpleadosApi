﻿namespace EmpleadosApi.Application.DTOs
{
    public class EmpleadoDto
    {
        public string NumeroEmp { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
    }
}
