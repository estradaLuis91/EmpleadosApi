﻿using System.Collections.Generic;
using System.Threading.Tasks;
using EmpleadosApi.Application.Interfaces;
using EmpleadosApi.Domain.Entities;
using EmpleadosApi.Domain.Interfaces;

namespace EmpleadosApi.Application.Services
{
    public class EmpleadoService : IEmpleadoService
    {
        private readonly IEmpleadoRepository _empleadoRepository;

        public EmpleadoService(IEmpleadoRepository empleadoRepository)
        {
            _empleadoRepository = empleadoRepository;
        }

        public async Task<Empleado> GetByIdAsync(int id)
        {
            return await _empleadoRepository.GetByIdAsync(id);
        }

        public async Task AddAsync(Empleado empleado)
        {
            await _empleadoRepository.AddAsync(empleado);
        }

        public async Task UpdateAsync(Empleados empleado)
        {
            await _empleadoRepository.UpdateAsync(empleado);
        }

        public async Task DeleteAsync(int id)
        {
            await _empleadoRepository.DeleteAsync(id);
        }
    }
}
