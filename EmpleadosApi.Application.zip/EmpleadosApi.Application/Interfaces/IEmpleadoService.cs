﻿using System.Collections.Generic;
using System.Threading.Tasks;
using EmpleadosApi.Domain.Entities;

namespace EmpleadosApi.Application.Interfaces
{
    public interface IEmpleadoService
    {
        Task<Empleado> GetByIdAsync(int id);
        Task AddAsync(Empleado empleado);
        Task UpdateAsync(Empleados empleado);
        Task DeleteAsync(int id);
    }
}
