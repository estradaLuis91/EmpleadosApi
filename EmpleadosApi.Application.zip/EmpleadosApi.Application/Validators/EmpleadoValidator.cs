﻿using EmpleadosApi.Domain.Entities;
using FluentValidation;

namespace EmpleadosApi.Application.Validators
{
    public class EmpleadoValidator : AbstractValidator<Empleado>
    {
        public EmpleadoValidator()
        {
            RuleFor(e => e.NumeroEmp)
                .NotEmpty().WithMessage("El número de empleado es obligatorio y no puede estar vacío.")
                .Must(numero => int.TryParse(numero.ToString(), out _)).WithMessage("El número de empleado debe ser un número entero válido.")
                .GreaterThan(0).WithMessage("El número de empleado debe ser mayor a cero.");

            RuleFor(e => e.Nombre)
                .NotEmpty().WithMessage("El nombre es obligatorio.")
                .Matches(@"^[a-zA-Z\s]+$").WithMessage("El nombre solo puede contener letras y espacios.");

            RuleFor(e => e.Apellidos)
                .NotEmpty().WithMessage("Los apellidos son obligatorios.")
                .Matches(@"^[a-zA-Z\s]+$").WithMessage("Los apellidos solo pueden contener letras y espacios.");
        }
    }
}
