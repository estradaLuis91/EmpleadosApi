﻿using EmpleadosApi.Domain.Entities;

namespace EmpleadosApi.Domain.Interfaces
{
    public interface IEmpleadoRepository
    {
        Task<IEnumerable<Empleado>> GetAllAsync();
        Task<Empleado> GetByIdAsync(int id);
        Task AddAsync(Empleado empleado);
        Task UpdateAsync(Empleados empleado);
        Task DeleteAsync(int id);
    }
}
