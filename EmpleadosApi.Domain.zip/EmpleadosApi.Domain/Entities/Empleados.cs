﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace EmpleadosApi.Domain.Entities
{
    public class Empleados
    {
        [JsonPropertyName("nombre")]
        [Required]
        public string Nombre { get; set; }

        [JsonPropertyName("apellidos")]
        [Required]
        public string Apellidos { get; set; }
    }
}
