﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace EmpleadosApi.Domain.Entities
{
    public class Empleado
    {
        [JsonPropertyName("numeroEmp")]
        [Required (ErrorMessage = "El número de empleado es obligatorio.")]
        public int NumeroEmp { get; set; }

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; }

        [JsonPropertyName("apellidos")]
        public string Apellidos { get; set; }
    }
}
