﻿using EmpleadosApi.Domain.Entities;
using EmpleadosApi.Domain.Interfaces;

namespace EmpleadosApi.Infrastructure.Repositories
{
    public class EmpleadoRepository : IEmpleadoRepository
    {
        private readonly List<Empleado> _empleados;

        public EmpleadoRepository()
        {
            // Datos de prueba.
            _empleados = new List<Empleado>
            {
                new Empleado { NumeroEmp = 123, Nombre = "Pedro" , Apellidos = "Perez Colin"},
                new Empleado { NumeroEmp = 213, Nombre = "Luis" ,  Apellidos = "Hernández Marquez"},
                new Empleado { NumeroEmp = 321, Nombre = "Lucia" ,  Apellidos = "Flores Vazquez"}
            };
        }

        public async Task<IEnumerable<Empleado>> GetAllAsync()
        {
            return await Task.FromResult(_empleados.AsEnumerable());
        }

        public async Task<Empleado> GetByIdAsync(int id)
        {
            var empleado = _empleados.FirstOrDefault(e => e.NumeroEmp == id);
            return await Task.FromResult(empleado);
        }

        public async Task AddAsync(Empleado empleado)
        {
            _empleados.Add(empleado);
            await Task.CompletedTask; 
        }

        public async Task UpdateAsync(Empleados empleado)
        {
  
            await Task.CompletedTask;
        }

        public async Task DeleteAsync(int id)
        {
            var empleado = _empleados.FirstOrDefault(e => e.NumeroEmp == id);
            if (empleado != null)
            {
                _empleados.Remove(empleado);
            }
            await Task.CompletedTask;
        }
    }
}
