﻿namespace EmpleadosApi.Infrastructure.Data
{
    public class AppDbContext
    {
    }
}
